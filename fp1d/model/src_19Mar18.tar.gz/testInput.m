clear all;
close all;
clc;
format longg

system('rm -v *png');

% inputFokkerPlanck = [3.89360873e-04  6.56689836e-03 -1.49999994e-03  1.35913222e-10 1.00062386e-06  2.10000000e-08]; % from getOptimalInput.py
% inputFokkerPlanck = [5.02085133e-03  4.49051540e-03 -6.48611998e-04  3.92629546e-04 3.02935332e-06];
% inputFokkerPlanck = [6.13452265e-03 -1.40450972e-03  4.90665253e-07  1.00000000e-09];
% inputFokkerPlanck = [5.02085133e-03  4.49051540e-03 -6.48611998e-04 1e-9];
% inputFokkerPlanck = [6.10100941e-03 -1.38820969e-03  5.14461403e-07  1.00000000e-09];
% inputFokkerPlanck = [  1.00000000e-04  -6.49796060e-01   0   1.0e+2];
% inputFokkerPlanck = [  1.00000000e-06  6.49796060e-01   1e-3   1.0e+3];
inputFokkerPlanck = [  1.00000000e-06  6.49796060e-01   0   5.0e+3];


% copy from ForwardFokkerPlanck.m 
% ----------------------------------- PARAMETERS SETTINGS ---------------------------- %
var = 'areaOfGrain';					% name of variable
N = 5.0e3; 								% number of segments
startSupp = -9.0e4; endSupp = 9.0e4;	% support
safeWidth = 0.1e4;						% width of zero density
dt = 1.0e+0;							% time-step
Nfrequency = 10/100 ;					% percentage - show progress at every Nfrequency
magFactor = 1e2; 						% magnifying factor to penalize the objective function
% startTime/endTime of ForwardFokkerPlanckModel
startTime 	= 1.375e0;					% startTime -- [time unit]
endTime  	= 1.1e4;					% endTime -- [time unit]
checkTime   = [10, 100, 1000, 10000]; 	% ad-hoc implementaton -- see log.spparks.partial

% inputFokkerPlanck = [-9.38918107390727e-06      0.000488148520734925      2.24355902008616e-06      -0.00200778588539395]; % good guess
% inputFokkerPlanck = [6.88060991180513e-06       -0.0360800529639008      3.08642806941265e-05        0.0154445707757066]; % good guess

% 12Mar18: impose constant diffusion term
lenInput = length(inputFokkerPlanck);
% polyDrift = inputFokkerPlanck( 1 : (lenInput - 2) ) ;
% polyDiffusion = inputFokkerPlanck(lenInput - 1 : end); 


% shiftRightToZero = 0.25;				% estimated shifted gamma distribution fit
O = 3;									% accuracy order of numerical derivatives
sourcePath = pwd;
Neverystep = 2.5e4;
h = (endSupp - startSupp)/N;
x = [startSupp:h:endSupp]; 				% discretized segment 
% ----------------------------------- OBJECTIVE FUNCTIONS ------------------------------- %
% open and save pdf at t=? where the pdf is matched at t=?
% see log.spparks.partial for more infor about time-series pdf

fprintf('Importing time-series pdf... \n');
pHistorySpparks = zeros(41, length(x));
for i = 0:39
	pHistorySpparks(i+1, :) = ksdensity(csvread(strcat(sourcePath,'/../probabilityRepo/','log.',var,'.', num2str(i), '.dat')), x);
	fprintf('Imported + Smoothed time-series pdf: %d/40... \n', i);
end
fprintf('Finished Importing time-series pdf... \n');





% ForwardFokkerPlanckModelOnlinePlot(inputFokkerPlanck)
ForwardFokkerPlanckModelOnlinePlotAfterCalib(inputFokkerPlanck, pHistorySpparks)

% ForwardFokkerPlanckModel(inputFokkerPlanck)

