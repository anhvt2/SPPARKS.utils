clear all;
close all;
clc;

system('rm -v *png');

% inputFokkerPlanck = [3.89360873e-04  6.56689836e-03 -1.49999994e-03  1.35913222e-10 1.00062386e-06  2.10000000e-08]; % from getOptimalInput.py
% inputFokkerPlanck = [5.02085133e-03  4.49051540e-03 -6.48611998e-04  3.92629546e-04 3.02935332e-06];
% inputFokkerPlanck = [6.13452265e-03 -1.40450972e-03  4.90665253e-07  1.00000000e-09];
% inputFokkerPlanck = [5.02085133e-03  4.49051540e-03 -6.48611998e-04 1e-9];
inputFokkerPlanck = [6.10100941e-03 -1.38820969e-03  5.14461403e-07  1.00000000e-09];


% ForwardFokkerPlanckModelOnlinePlot(inputFokkerPlanck)
ForwardFokkerPlanckModelOnlinePlotAfterCalib(inputFokkerPlanck)

% ForwardFokkerPlanckModel(inputFokkerPlanck)

