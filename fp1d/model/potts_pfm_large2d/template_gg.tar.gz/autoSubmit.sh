#!/bin/bash

for i in $(seq 0 100000); do
	cd $i
	ln -sf ../template/sbatch.spparks.solo
	ln -sf ../template/in.grain_growth.spk
	sdel
	ssubmit
	cd ..
done
