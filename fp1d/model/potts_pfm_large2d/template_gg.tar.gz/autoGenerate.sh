#!/bin/bash

for i in $(seq 0 100000); do
	cp -rfv template $i
	ln -sf template/sbatch.spparks.solo  $i
done
