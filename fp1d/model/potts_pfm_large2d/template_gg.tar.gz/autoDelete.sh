#!/bin/bash

for i in $(seq 0 100000); do
	rm -rfv $i/*jpg
done
