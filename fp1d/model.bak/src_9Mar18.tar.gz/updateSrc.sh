versionDate='9Mar18'
# rm -v *.tar.gz

echo "Commands activate:"

for fileName in $(ls *_${versionDate}*); do
	filePrefix=$(echo $fileName | cut -d_ -f1)
	fileAppendix=$(echo $fileName | cut -d. -f2)
	echo "cp -v ${fileName} ${filePrefix}.${fileAppendix}"
	cp -v ${fileName} ${filePrefix}.${fileAppendix}
done

echo; echo;

tar -cvzf src_${versionDate}.tar.gz *m *py *txt *dat *sh bayesSrc/ dace/
rm src.tar

echo; echo;

echo "Files updated:"
ls *_${versionDate}*

echo; echo;
echo "note: tar into src_${versionDate}.tar.gz"
echo; echo;
