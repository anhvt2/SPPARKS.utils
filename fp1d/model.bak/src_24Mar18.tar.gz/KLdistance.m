function dKL = KLdistance(p,q,x)
	% Kullback-Leibler distance w.r.t p; p = reference density

	% assuming p and q die out at the boundary of x
	if length(p) ~= length(q) 
		error('Discretized length of 2 distributions are not the same');
	end
	if length(p) ~= length(x) 
		error('Discretized length of distribution p and support are not the same');
	end
	if length(q) ~= length(x) 
		error('Discretized length of distribution q and support are not the same');
	end

	% p = experimental
	% q = simulated
	tol = eps; 
	% (1) prevent NaN numerical issue - too small -> +NaN
	% (2) p(i) = 0 -> log 0 = -NaN
	for i = 1:length(x)
		if q(i) > tol && p(i) > tol
			integralFunction(i) = p(i) * log( p(i) / q(i) );
		else
			integralFunction(i) = 0;
		end
	end
	% https://en.wikipedia.org/wiki/Kullback-Leibler_divergence
	dKL = trapz( x , real(integralFunction) );
end

