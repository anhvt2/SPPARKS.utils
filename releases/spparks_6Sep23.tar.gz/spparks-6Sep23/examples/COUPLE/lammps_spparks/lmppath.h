// path to your LAMMPS home directory

#define LMPPATH /home/sjplimp/lammps/git
