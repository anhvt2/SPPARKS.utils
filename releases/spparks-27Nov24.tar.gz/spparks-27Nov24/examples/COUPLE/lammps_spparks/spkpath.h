// path to your SPPARKS home directory

#define SPKPATH /home/sjplimp/spparks/git
